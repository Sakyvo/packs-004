Hello and welcome to the Monochrom resource pack! This pack was an experiment to find some good black-and-white Minecraft textures, because why not.

This texture pack should only appear on PlanetMinecraft.com, nowhere else without permission.
As with all texture packs, please do not redistribute this pack without my permission (though those who do tend to disregard this message anyway).

If you are interested in any of my custom textures or would like to contact me for any reason, please PM me on PlanetMinecraft at Ohhithere1543.

Enjoy!